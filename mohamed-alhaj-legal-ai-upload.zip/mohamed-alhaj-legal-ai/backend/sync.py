import hashlib, os, time, urllib.robotparser
from urllib.parse import urljoin, urlparse
import requests
from bs4 import BeautifulSoup
from backend.db import connect

ROOTS = {
    "laws": "https://www.yemenilaw.com/library/yemeni-laws/",
    "cases": "https://www.yemenilaw.com/",
    "contracts": "https://www.yemenilaw.com/contracts/",
}
ALLOWED_HOSTS = {"www.yemenilaw.com", "yemenilaw.com"}
HEADERS = {"User-Agent": "MohamedAlhajLegalAI-ResearchBot/1.0"}

def sync(max_pages=None):
    max_pages = max_pages or int(os.getenv("SYNC_MAX_PAGES", "120"))
    session = requests.Session()
    session.headers.update(HEADERS)
    rp = urllib.robotparser.RobotFileParser()
    rp.set_url("https://www.yemenilaw.com/robots.txt")
    try:
        rp.read()
    except Exception:
        return {"status": "blocked", "error": "تعذر قراءة robots.txt؛ أوقفت الفهرسة."}

    queue = [(u, section) for section, u in ROOTS.items()]
    seen, changed, errors = set(), 0, 0
    with connect() as con:
        run_id = con.execute("INSERT INTO sync_runs(status) VALUES('running')").lastrowid

    while queue and len(seen) < max_pages:
        url, section = queue.pop(0)
        parsed = urlparse(url)
        if (url in seen or parsed.scheme != "https" or parsed.hostname not in ALLOWED_HOSTS
                or not rp.can_fetch(HEADERS["User-Agent"], url)):
            continue
        seen.add(url)
        try:
            response = session.get(url, timeout=20)
            response.raise_for_status()
            if "text/html" not in response.headers.get("content-type", ""):
                continue
            soup = BeautifulSoup(response.text, "html.parser")
            for tag in soup(["script", "style", "nav", "footer", "header"]):
                tag.decompose()
            title = soup.title.get_text(" ", strip=True) if soup.title else url
            main = soup.find("main") or soup.find("article") or soup.body or soup
            content = " ".join(main.stripped_strings)[:150000]
            digest = hashlib.sha256(content.encode()).hexdigest()

            with connect() as con:
                old = con.execute("SELECT id, content_hash FROM documents WHERE url=?", (url,)).fetchone()
                if old is None:
                    doc_id = con.execute(
                        "INSERT INTO documents(url,title,section,content,content_hash) VALUES(?,?,?,?,?)",
                        (url, title, section, content, digest)
                    ).lastrowid
                    con.execute(
                        "INSERT INTO change_events(document_id,url,event_type,new_hash,details) VALUES(?,?,?,?,?)",
                        (doc_id, url, "new", digest, "صفحة جديدة")
                    )
                    con.execute("INSERT INTO documents_fts(rowid,title,content,url) VALUES(?,?,?,?)",
                                (doc_id, title, content, url))
                    changed += 1
                else:
                    doc_id = old["id"]
                    if old["content_hash"] != digest:
                        con.execute(
                            "INSERT INTO document_snapshots(document_id,title,content,content_hash) "
                            "SELECT id,title,content,content_hash FROM documents WHERE id=?", (doc_id,)
                        )
                        con.execute(
                            "UPDATE documents SET title=?,content=?,content_hash=?,last_seen=CURRENT_TIMESTAMP WHERE id=?",
                            (title, content, digest, doc_id)
                        )
                        con.execute("DELETE FROM documents_fts WHERE rowid=?", (doc_id,))
                        con.execute("INSERT INTO documents_fts(rowid,title,content,url) VALUES(?,?,?,?)",
                                    (doc_id, title, content, url))
                        con.execute(
                            "INSERT INTO change_events(document_id,url,event_type,old_hash,new_hash,details) "
                            "VALUES(?,?,?,?,?,?)",
                            (doc_id, url, "changed", old["content_hash"], digest, "تغير محتوى الصفحة")
                        )
                        changed += 1
                    else:
                        con.execute("UPDATE documents SET last_seen=CURRENT_TIMESTAMP WHERE id=?", (doc_id,))

            for anchor in soup.find_all("a", href=True):
                nxt = urljoin(url, anchor["href"]).split("#")[0]
                if urlparse(nxt).hostname in ALLOWED_HOSTS and nxt not in seen:
                    if all(item[0] != nxt for item in queue):
                        queue.append((nxt, section))
            time.sleep(1.5)
        except Exception:
            errors += 1

    with connect() as con:
        con.execute(
            "UPDATE sync_runs SET finished_at=CURRENT_TIMESTAMP,pages_seen=?,errors=?,status='completed',notes=? WHERE id=?",
            (len(seen), errors, f"صفحات جديدة أو متغيرة: {changed}", run_id)
        )
    return {"status": "completed", "pages_seen": len(seen), "changes": changed, "errors": errors}
