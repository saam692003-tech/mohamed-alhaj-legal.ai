import os, sqlite3
from pathlib import Path

DB_PATH = os.getenv("DATABASE_PATH", "./data/legal_ai.sqlite3")

def connect():
    Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB_PATH, timeout=30)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with connect() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS documents (
          id INTEGER PRIMARY KEY, url TEXT UNIQUE NOT NULL, title TEXT NOT NULL DEFAULT '',
          section TEXT NOT NULL DEFAULT 'other', content TEXT NOT NULL DEFAULT '',
          content_hash TEXT NOT NULL, first_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
          last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, status TEXT NOT NULL DEFAULT 'active'
        );
        CREATE TABLE IF NOT EXISTS document_snapshots (
          id INTEGER PRIMARY KEY, document_id INTEGER NOT NULL, captured_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
          title TEXT, content TEXT, content_hash TEXT NOT NULL,
          FOREIGN KEY(document_id) REFERENCES documents(id)
        );
        CREATE TABLE IF NOT EXISTS change_events (
          id INTEGER PRIMARY KEY, document_id INTEGER, url TEXT NOT NULL, event_type TEXT NOT NULL,
          old_hash TEXT, new_hash TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
          details TEXT DEFAULT ''
        );
        CREATE VIRTUAL TABLE IF NOT EXISTS documents_fts USING fts5(title, content, url UNINDEXED);
        CREATE TABLE IF NOT EXISTS sync_runs (
          id INTEGER PRIMARY KEY, started_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
          finished_at TEXT, pages_seen INTEGER DEFAULT 0, errors INTEGER DEFAULT 0,
          status TEXT DEFAULT 'running', notes TEXT DEFAULT ''
        );
        """)

def search_docs(q: str, limit: int = 20):
    with connect() as con:
        rows = con.execute(
            "SELECT title, url, snippet(documents_fts, 1, '<b>', '</b>', '…', 18) AS excerpt "
            "FROM documents_fts WHERE documents_fts MATCH ? LIMIT ?", (q, limit)
        ).fetchall()
        return [dict(r) for r in rows]
