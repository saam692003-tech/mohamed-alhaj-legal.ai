import os
from contextlib import asynccontextmanager
from fastapi import FastAPI, Header, HTTPException, Query
from fastapi.responses import HTMLResponse
from apscheduler.schedulers.background import BackgroundScheduler
from backend.db import init_db, connect, search_docs
from backend.sync import sync

scheduler = BackgroundScheduler(timezone="Asia/Aden")

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    if not scheduler.running:
        scheduler.add_job(sync, "cron", day_of_week="mon", hour=10, minute=0,
                          id="weekly-legal-sync", replace_existing=True)
        scheduler.start()
    yield
    if scheduler.running:
        scheduler.shutdown(wait=False)

app = FastAPI(title="Mohamed Alhaj Legal AI", version="0.9.0", lifespan=lifespan)

@app.get("/", response_class=HTMLResponse)
def home():
    return """<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>محمد الحاج | المساعد القانوني اليمني</title>
    <style>body{font-family:Tahoma,Arial;background:#101a2b;color:#f5f2e9;margin:0}
    .wrap{max-width:900px;margin:8vh auto;padding:24px}.card{background:#192941;
    border:1px solid #b99755;border-radius:16px;padding:28px}h1{color:#d9b66e}
    input,button{font:inherit;padding:14px;border-radius:8px;border:0}
    input{width:65%;max-width:600px}button{background:#c5a15d;color:#101a2b;cursor:pointer}
    .muted{color:#c5cbd5}a{color:#e4c77f}</style>
    <div class="wrap"><div class="card"><h1>محمد الحاج — المساعد القانوني اليمني</h1>
    <p>بوابة بحث أولية في فهرس المصادر القانونية اليمنية.</p>
    <form action="/search"><input name="q" placeholder="اكتب موضوع البحث أو كلمات قانونية" required>
    <button>بحث</button></form><p class="muted">يجب التحقق من النصوص الرسمية والتعديلات قبل الاستناد إليها.</p>
    <p><a href="/api/health">حالة الخدمة</a> · <a href="/docs">واجهات API</a></p>
    </div></div></html>"""

@app.get("/api/health")
def health():
    with connect() as con:
        count = con.execute("SELECT COUNT(*) FROM documents").fetchone()[0]
    return {"status": "ok", "documents": count, "version": "0.9.0"}

@app.get("/search", response_class=HTMLResponse)
def search_page(q: str = Query(min_length=2)):
    results = search_docs(q, 30)
    cards = "".join(
        f'<li><a href="{r["url"]}" target="_blank">{r["title"]}</a><p>{r["excerpt"]}</p></li>'
        for r in results
    )
    return (f'<html lang="ar" dir="rtl"><meta charset="utf-8"><body '
            f'style="font-family:Tahoma;background:#101a2b;color:#fff;padding:24px">'
            f'<h2>نتائج البحث: {q}</h2><ol>{cards or "لا توجد نتائج مفهرسة بعد."}</ol>'
            f'<a href="/">عودة</a></body></html>')

@app.get("/api/sync/status")
def sync_status():
    with connect() as con:
        last = con.execute("SELECT * FROM sync_runs ORDER BY id DESC LIMIT 1").fetchone()
        docs = con.execute("SELECT COUNT(*) FROM documents").fetchone()[0]
    return {"documents": docs, "last_run": dict(last) if last else None}

@app.get("/api/sync/changes")
def changes(limit: int = Query(50, ge=1, le=200)):
    with connect() as con:
        return [dict(r) for r in con.execute(
            "SELECT * FROM change_events ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()]

@app.post("/api/admin/sync")
def admin_sync(x_admin_token: str = Header(default="")):
    if not os.getenv("ADMIN_TOKEN") or x_admin_token != os.getenv("ADMIN_TOKEN"):
        raise HTTPException(status_code=401, detail="Unauthorized")
    return sync()
